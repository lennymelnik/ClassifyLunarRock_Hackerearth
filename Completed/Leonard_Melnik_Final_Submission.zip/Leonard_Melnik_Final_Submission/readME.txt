Hello, my name is Leonard Melnik. For the Classify the Lunar Rock: Hackerearth Data Science Competition I achieved 99.65% Accuracy.

This was my ML competition and I am happy with my results. I did not need to do any major feature engineering, since all we had were the images and their classes. 

In order to engineer more feautes I used the Tensorflow ImageDataGenerator for each DIR that contained images. In order to make training and validation data. I used this software called split-folders.

In the assets folder you will find my submitted CSV along with the trained model and the __init__.py contains all the code (Aside from Split-Folders)


